package eu.kanade.tachiyomi.ui.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation3.runtime.result.LocalResultEventBus
import dev.zacsweers.metrox.viewmodel.metroViewModel
import eu.kanade.presentation.manga.components.MangaCover
import eu.kanade.tachiyomi.ui.home.TabEvent
import mihon.core.navigation.LocalNavigator
import mihon.core.navigation.MangaRoute
import tachiyomi.domain.history.model.HistoryWithRelations
import java.time.LocalTime
import kotlin.time.Clock
import kotlin.time.Instant

@Composable
fun DashboardTab() {
    val navigator = LocalNavigator.current
    val resultEventBus = LocalResultEventBus.current
    val viewModel = metroViewModel<DashboardViewModel>()
    val state by viewModel.state.collectAsStateWithLifecycle()

    DashboardScreen(
        state = state,
        onOpenManga = { navigator.push(MangaRoute(it)) },
        onOpenTab = { resultEventBus.sendResult<TabEvent>(it) },
    )
}

@Composable
private fun DashboardScreen(
    state: DashboardState,
    onOpenManga: (Long) -> Unit,
    onOpenTab: (TabEvent) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Header()
        ContinueCard(state.recent.firstOrNull(), onOpenManga)
        StatsGrid(state, onOpenTab)
        QuickActions(onOpenTab)
        RecentShelf(state.recent.drop(1), onOpenManga)
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Header() {
    val colors = MaterialTheme.colorScheme
    val hour = LocalTime.now().hour
    val greeting = when {
        hour < 11 -> "Selamat pagi"
        hour < 15 -> "Selamat siang"
        hour < 18 -> "Selamat sore"
        else -> "Selamat malam"
    }
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(colors.primary, colors.tertiary)))
            .padding(horizontal = 20.dp, vertical = 24.dp),
    ) {
        Column {
            Text(text = greeting, color = colors.onPrimary.copy(alpha = 0.85f), fontSize = 15.sp)
            Text(
                text = "FaManga",
                color = colors.onPrimary,
                fontSize = 34.sp,
                fontWeight = FontWeight.ExtraBold,
            )
            Text(
                text = "Baca dan lanjutkan ceritamu.",
                color = colors.onPrimary.copy(alpha = 0.85f),
                fontSize = 13.sp,
            )
        }
    }
}

@Composable
private fun ContinueCard(
    item: HistoryWithRelations?,
    onOpenManga: (Long) -> Unit,
) {
    val colors = MaterialTheme.colorScheme
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(colors.surfaceContainerHigh)
            .then(if (item != null) Modifier.clickable { onOpenManga(item.mangaId) } else Modifier)
            .padding(14.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (item == null) {
            Text(
                text = "Belum ada riwayat. Buka Jelajahi untuk menemukan bacaan pertamamu.",
                color = colors.onSurfaceVariant,
            )
            return@Row
        }
        MangaCover.Book(
            data = item.coverData,
            modifier = Modifier.width(84.dp),
            contentDescription = item.title,
            shape = RoundedCornerShape(14.dp),
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "LANJUTKAN",
                color = colors.primary,
                fontSize = 11.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.4.sp,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = item.title,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = listOf(chapterLabel(item.chapterNumber), formatAgo(item.readAt))
                    .filter { it.isNotEmpty() }
                    .joinToString(" · "),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = colors.onSurfaceVariant,
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = { onOpenManga(item.mangaId) }) {
                Text("Buka")
            }
        }
    }
}

@Composable
private fun StatsGrid(
    state: DashboardState,
    onOpenTab: (TabEvent) -> Unit,
) {
    val colors = MaterialTheme.colorScheme
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionTitle("Koleksimu")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile(
                label = "Di library",
                value = state.libraryCount.toString(),
                from = colors.primary,
                to = colors.primary.copy(alpha = 0.65f),
                content = colors.onPrimary,
                onClick = { onOpenTab(TabEvent.Library()) },
            )
            StatTile(
                label = "Belum dibaca",
                value = state.unreadChapters.toString(),
                from = colors.secondary,
                to = colors.secondary.copy(alpha = 0.65f),
                content = colors.onSecondary,
                onClick = { onOpenTab(TabEvent.Updates) },
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatTile(
                label = "Bab dibaca",
                value = state.readChapters.toString(),
                from = colors.tertiary,
                to = colors.tertiary.copy(alpha = 0.65f),
                content = colors.onTertiary,
                onClick = { onOpenTab(TabEvent.History) },
            )
            StatTile(
                label = "Waktu baca",
                value = formatDuration(state.readDurationMs),
                from = colors.primaryContainer,
                to = colors.inversePrimary,
                content = colors.onPrimaryContainer,
                onClick = { onOpenTab(TabEvent.History) },
            )
        }
    }
}

@Composable
private fun RowScope.StatTile(
    label: String,
    value: String,
    from: Color,
    to: Color,
    content: Color,
    onClick: () -> Unit,
) {
    Column(
        modifier = Modifier
            .weight(1f)
            .clip(RoundedCornerShape(22.dp))
            .background(Brush.linearGradient(listOf(from, to)))
            .clickable(onClick = onClick)
            .padding(16.dp),
    ) {
        Text(text = value, color = content, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
        Text(text = label, color = content.copy(alpha = 0.9f), fontSize = 13.sp)
    }
}

@Composable
private fun QuickActions(onOpenTab: (TabEvent) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SectionTitle("Aksi cepat")
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            AssistChip(onClick = { onOpenTab(TabEvent.Browse()) }, label = { Text("Jelajahi") })
            AssistChip(onClick = { onOpenTab(TabEvent.Updates) }, label = { Text("Pembaruan") })
            AssistChip(onClick = { onOpenTab(TabEvent.History) }, label = { Text("Riwayat") })
            AssistChip(onClick = { onOpenTab(TabEvent.More(toDownloads = false)) }, label = { Text("Lainnya") })
        }
    }
}

@Composable
private fun RecentShelf(
    entries: List<HistoryWithRelations>,
    onOpenManga: (Long) -> Unit,
) {
    if (entries.isEmpty()) return
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SectionTitle("Terakhir dibuka")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(entries, key = { it.mangaId }) { item ->
                Column(
                    modifier = Modifier
                        .width(112.dp)
                        .clickable { onOpenManga(item.mangaId) },
                ) {
                    MangaCover.Book(
                        data = item.coverData,
                        modifier = Modifier.width(112.dp),
                        contentDescription = item.title,
                        shape = RoundedCornerShape(14.dp),
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = item.title,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text = text, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
}

private fun chapterLabel(number: Double): String {
    if (number < 0) return ""
    val text = if (number % 1.0 == 0.0) number.toLong().toString() else number.toString()
    return "Bab $text"
}

private fun formatDuration(ms: Long): String {
    val minutes = ms / 60_000
    val hours = minutes / 60
    return if (hours > 0) "${hours}j ${minutes % 60}m" else "${minutes}m"
}

private fun formatAgo(readAt: Instant?): String {
    readAt ?: return ""
    val elapsed = Clock.System.now() - readAt
    return when {
        elapsed.inWholeMinutes < 1 -> "baru saja"
        elapsed.inWholeMinutes < 60 -> "${elapsed.inWholeMinutes} menit lalu"
        elapsed.inWholeHours < 24 -> "${elapsed.inWholeHours} jam lalu"
        else -> "${elapsed.inWholeDays} hari lalu"
    }
}
