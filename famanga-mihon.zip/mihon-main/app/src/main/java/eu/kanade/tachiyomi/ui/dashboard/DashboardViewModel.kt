package eu.kanade.tachiyomi.ui.dashboard

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dev.zacsweers.metro.AppScope
import dev.zacsweers.metro.ContributesIntoMap
import dev.zacsweers.metro.Inject
import dev.zacsweers.metro.binding
import dev.zacsweers.metrox.viewmodel.ViewModelKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import tachiyomi.domain.history.interactor.GetHistory
import tachiyomi.domain.history.model.HistoryWithRelations
import tachiyomi.domain.manga.interactor.GetLibraryManga
import kotlin.time.Duration.Companion.seconds

@Inject
@ViewModelKey
@ContributesIntoMap(AppScope::class, binding = binding<ViewModel>())
class DashboardViewModel(
    getLibraryManga: GetLibraryManga,
    getHistory: GetHistory,
) : ViewModel() {

    val state: StateFlow<DashboardState> = combine(
        getLibraryManga.subscribe(),
        getHistory.subscribe(""),
    ) { library, history ->
        DashboardState(
            libraryCount = library.size,
            unreadChapters = library.sumOf { it.unreadCount },
            readChapters = library.sumOf { it.readCount },
            readDurationMs = history.sumOf { it.readDuration },
            recent = history
                .filter { it.readAt != null }
                .sortedByDescending { it.readAt }
                .distinctBy { it.mangaId }
                .take(RECENT_LIMIT),
        )
    }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5.seconds), DashboardState())

    private companion object {
        const val RECENT_LIMIT = 10
    }
}

@Immutable
data class DashboardState(
    val libraryCount: Int = 0,
    val unreadChapters: Long = 0,
    val readChapters: Long = 0,
    val readDurationMs: Long = 0,
    val recent: List<HistoryWithRelations> = emptyList(),
)
